var searchData=
[
  ['main_5fpost_5fprocessing_3a_20plot_20the_20result_20from_20the_20split_2dstep_20wavelet_20propagation_20module_13',['main_post_processing: Plot the result from the split-step wavelet propagation module',['../index.html',1,'']]]
];
