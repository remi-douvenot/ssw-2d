var searchData=
[
  ['plot_5f2d_5fwavelet_75',['plot_2D_wavelet',['../namespacelibrary__generation.html#a4d8b283d99d426b7b8def142da8ad1fe',1,'library_generation']]]
];
