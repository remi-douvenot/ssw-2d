var searchData=
[
  ['compute_5fimage_5ffield_4',['compute_image_field',['../namespacecompute__image__field.html',1,'']]],
  ['compute_5fspectral_5fpropagator_5',['compute_spectral_propagator',['../namespacecompute__spectral__propagator.html',1,'']]],
  ['compute_5fthreshold_6',['compute_threshold',['../namespacecompute__threshold.html',1,'']]],
  ['compute_5fthresholds_2epy_7',['compute_thresholds.py',['../compute__thresholds_8py.html',1,'']]],
  ['config_8',['Config',['../classclasses_1_1_config.html',1,'classes']]],
  ['create_5fdssf_5fscaling_5ffct_9',['create_DSSF_scaling_fct',['../namespacecreate___d_s_s_f__scaling__fct.html',1,'']]],
  ['create_5fdssf_5fwavelet_10',['create_DSSF_wavelet',['../namespacecreate___d_s_s_f__wavelet.html',1,'']]]
];
