var searchData=
[
  ['sigma_79',['sigma',['../classmain__propagation_1_1config.html#aa61a907ecfbcbb507881627276cb1383',1,'main_propagation::config']]]
];
