var searchData=
[
  ['init_5flibrary_17',['init_library',['../namespaceinit__library.html',1,'']]]
];
