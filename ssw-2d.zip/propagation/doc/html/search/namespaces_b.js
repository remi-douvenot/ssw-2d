var searchData=
[
  ['thresholding_62',['thresholding',['../namespacethresholding.html',1,'']]]
];
