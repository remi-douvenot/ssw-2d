var searchData=
[
  ['thresholding_31',['thresholding',['../namespacethresholding.html',1,'']]],
  ['thresholding_2epy_32',['thresholding.py',['../thresholding_8py.html',1,'']]]
];
