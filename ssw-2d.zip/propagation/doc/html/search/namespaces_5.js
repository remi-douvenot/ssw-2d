var searchData=
[
  ['init_5flibrary_53',['init_library',['../namespaceinit__library.html',1,'']]]
];
