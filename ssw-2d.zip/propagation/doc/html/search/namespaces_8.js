var searchData=
[
  ['q_5fmax_5fcalculation_56',['q_max_calculation',['../namespaceq__max__calculation.html',1,'']]]
];
