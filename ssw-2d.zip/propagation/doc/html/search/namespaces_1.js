var searchData=
[
  ['compute_5fimage_5ffield_43',['compute_image_field',['../namespacecompute__image__field.html',1,'']]],
  ['compute_5fspectral_5fpropagator_44',['compute_spectral_propagator',['../namespacecompute__spectral__propagator.html',1,'']]],
  ['compute_5fthreshold_45',['compute_threshold',['../namespacecompute__threshold.html',1,'']]],
  ['create_5fdssf_5fscaling_5ffct_46',['create_DSSF_scaling_fct',['../namespacecreate___d_s_s_f__scaling__fct.html',1,'']]],
  ['create_5fdssf_5fwavelet_47',['create_DSSF_wavelet',['../namespacecreate___d_s_s_f__wavelet.html',1,'']]]
];
