var searchData=
[
  ['shift_5ffield_58',['shift_field',['../namespaceshift__field.html',1,'']]],
  ['sparsify_59',['sparsify',['../namespacesparsify.html',1,'']]],
  ['ssw_5f2d_60',['SSW_2D',['../namespace_s_s_w__2_d.html',1,'']]],
  ['ssw_5f2d_5fone_5fstep_61',['ssw_2d_one_step',['../namespacessw__2d__one__step.html',1,'']]]
];
