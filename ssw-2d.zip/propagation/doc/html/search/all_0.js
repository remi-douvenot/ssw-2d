var searchData=
[
  ['add_5fpropagator_5fat_5fonce_0',['add_propagator_at_once',['../namespaceadd__propagator__at__once.html',1,'']]],
  ['apodisation_5fwindow_1',['apodisation_window',['../namespaceapodisation__window.html',1,'']]],
  ['apply_5fapodisation_2',['apply_apodisation',['../namespaceapply__apodisation.html',1,'']]],
  ['apply_5frefractive_5findex_3',['apply_refractive_index',['../namespaceapply__refractive__index.html',1,'']]]
];
