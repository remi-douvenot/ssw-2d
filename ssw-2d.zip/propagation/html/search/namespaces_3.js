var searchData=
[
  ['eliminate_5ftop_5ffield_59',['eliminate_top_field',['../namespaceeliminate__top__field.html',1,'']]],
  ['eliminate_5ftop_5fwavelets_60',['eliminate_top_wavelets',['../namespaceeliminate__top__wavelets.html',1,'']]]
];
