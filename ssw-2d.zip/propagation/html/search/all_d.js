var searchData=
[
  ['thresholding_37',['thresholding',['../namespacethresholding.html',1,'']]],
  ['thresholding_2epy_38',['thresholding.py',['../thresholding_8py.html',1,'']]]
];
