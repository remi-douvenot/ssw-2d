var searchData=
[
  ['thresholding_74',['thresholding',['../namespacethresholding.html',1,'']]]
];
