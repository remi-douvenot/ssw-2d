var searchData=
[
  ['n_5fim_71',['N_im',['../classmain__propagation_1_1config.html#a631d663158741b846c18dff4fcfa8168',1,'main_propagation::config']]],
  ['n_5frefraction_72',['n_refraction',['../namespacemain__propagation.html#a1763216f26f92af8d66594daf82a6873',1,'main_propagation']]]
];
