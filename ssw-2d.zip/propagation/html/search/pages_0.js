var searchData=
[
  ['main_5fpropagation_3a_20core_20program_20of_20the_20split_2dstep_20wavelet_20ssw_2d2d_20package_89',['main_propagation: Core program of the split-step wavelet SSW-2D package',['../index.html',1,'']]]
];
