var searchData=
[
  ['wavelet_5fpropagation_2epy_87',['wavelet_propagation.py',['../wavelet__propagation_8py.html',1,'']]]
];
