var searchData=
[
  ['fortran_5ftype_61',['fortran_type',['../namespacefortran__type.html',1,'']]],
  ['fresnel_5fcoefficient_62',['fresnel_coefficient',['../namespacefresnel__coefficient.html',1,'']]]
];
