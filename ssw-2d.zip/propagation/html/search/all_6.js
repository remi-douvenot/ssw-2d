var searchData=
[
  ['init_5flibrary_21',['init_library',['../namespaceinit__library.html',1,'']]]
];
