var searchData=
[
  ['shift_5ffield_69',['shift_field',['../namespaceshift__field.html',1,'']]],
  ['sparsify_70',['sparsify',['../namespacesparsify.html',1,'']]],
  ['ssw_5f2d_71',['SSW_2D',['../namespace_s_s_w__2_d.html',1,'']]],
  ['ssw_5f2d_5fone_5fstep_72',['ssw_2d_one_step',['../namespacessw__2d__one__step.html',1,'']]],
  ['surface_5fwave_5fpropagation_73',['surface_wave_propagation',['../namespacesurface__wave__propagation.html',1,'']]]
];
