var searchData=
[
  ['init_5flibrary_64',['init_library',['../namespaceinit__library.html',1,'']]]
];
