var searchData=
[
  ['dependencies_7',['Dependencies',['../classdependencies_1_1_dependencies.html',1,'dependencies']]]
];
