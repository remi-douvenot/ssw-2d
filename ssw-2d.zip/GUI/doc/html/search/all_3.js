var searchData=
[
  ['plots_4',['Plots',['../classplots_1_1_plots.html',1,'plots']]]
];
