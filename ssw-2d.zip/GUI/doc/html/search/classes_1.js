var searchData=
[
  ['plots_8',['Plots',['../classplots_1_1_plots.html',1,'plots']]]
];
